
void nice_eth_on();
void nice_eth_off();
void nice_eth_udp_len(unsigned len, unsigned fre);

void eth_test();
void eth_once();
