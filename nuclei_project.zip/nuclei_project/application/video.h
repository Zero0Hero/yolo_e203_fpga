
void nice_cam_on();
void nice_cam_off();

void nice_hdmi_on();
void nice_hdmi_off();

